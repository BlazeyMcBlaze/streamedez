import xbmc
import requests
import json

class APIClient:
    def __init__(self, base_url):
        self.base_url = base_url.rstrip('/')
        self.timeout = 2
    
    def _make_request(self, endpoint, method='GET', data=None, params=None):
        """Executes HTTP requests to the API bridge."""
        try:
            url = f"{self.base_url}/{endpoint.lstrip('/')}"
            xbmc.log(f"StreamedEZ: API Request: {url}", xbmc.LOGINFO)
            
            if method == 'POST':
                response = requests.post(url, json=data, timeout=self.timeout)
            else:
                response = requests.get(url, params=params, timeout=self.timeout)
            
            response.raise_for_status()
            return response.json()
            
        except requests.exceptions.Timeout:
            xbmc.log("StreamedEZ: API Timeout", xbmc.LOGERROR)
            raise Exception(f"Connection timed out (2s). Check API settings.\nCurrent URL: {self.base_url}")
            
        except requests.exceptions.ConnectionError:
            xbmc.log("StreamedEZ: API Connection Error", xbmc.LOGERROR)
            raise Exception(f"Could not connect. Check API settings.\nCurrent URL: {self.base_url}")
            
        except requests.exceptions.HTTPError as e:
            xbmc.log(f"StreamedEZ: API HTTP Error {e.response.status_code}", xbmc.LOGERROR)
            raise Exception(f"Server Error ({e.response.status_code})")
            
        except Exception as e:
            xbmc.log(f"StreamedEZ: API Request failed: {str(e)}", xbmc.LOGERROR)
            raise Exception(f"API Error: {str(e)}")
    
    def get_sports(self):
        """Retrieves the list of available sports."""
        return self._make_request('full/sports')

    def get_kodi_data(self):
        """Retrieves the full dataset for Kodi consumption."""
        return self._make_request('kodi/data.json')