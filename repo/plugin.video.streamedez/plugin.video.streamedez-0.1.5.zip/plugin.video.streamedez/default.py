import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import sys
import urllib.parse
import requests
import base64
import re
import certifi
from datetime import datetime, timedelta

try:
    from resources.lib.api_client import APIClient
    from resources.lib.cache_helper import CacheHelper
except ImportError:
    from api_client import APIClient
    from cache_helper import CacheHelper

ADDON = xbmcaddon.Addon()
ADDON_NAME = ADDON.getAddonInfo('name')
ADDON_HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]
BRIDGE_API_URL = ADDON.getSetting('api_bridge_url')

api_client = APIClient(BRIDGE_API_URL)
cache_helper = CacheHelper()

# [UPDATED] Hardcoded Cache TTLs (Hours)
TTL_SPORTS = 24     # Sports list rarely changes
TTL_MATCHES = 0.05  # 3 minutes (Matches/Streams need to be fresh)

def log(msg, level=xbmc.LOGINFO):
    """Wrapper for xbmc logging."""
    xbmc.log(f"StreamedEZ: {msg}", level)

def build_url(query):
    """Constructs the plugin URL with query parameters."""
    return BASE_URL + '?' + urllib.parse.urlencode(query)

def force_refresh():
    """Clears cache and reloads the current directory."""
    cache_helper.clear()
    xbmcgui.Dialog().notification(ADDON_NAME, 'Data Refreshed', xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin('Container.Refresh')

def get_sports_list():
    """Fetches list of sports."""
    cached = cache_helper.get('sports_list')
    if cached: return cached
    
    try:
        response = api_client.get_sports()
        if response and 'sports' in response:
            data = response['sports']
            cache_helper.set('sports_list', data, ttl_hours=TTL_SPORTS)
            return data
    except Exception as e:
        log(f"Failed to load sports list: {str(e)}", xbmc.LOGERROR)
        return []
    return []

def get_kodi_data(force_update=False):
    """Fetches the main data payload from the API."""
    if not force_update:
        cached = cache_helper.get('kodi_data')
        if cached: return cached
    
    try:
        pDialog = xbmcgui.DialogProgress()
        pDialog.create(ADDON_NAME, 'Fetching latest schedule...')
        pDialog.update(50)
        
        data = api_client.get_kodi_data()
        pDialog.close()
        
        if data:
            cache_helper.set('kodi_data', data, ttl_hours=TTL_MATCHES) 
            return data
    except Exception as e:
        pDialog.close()
        log(f"Failed to load match data: {str(e)}", xbmc.LOGERROR)
        return None
        
    return None

def format_match_time(ts):
    """Formats timestamp into readable string."""
    if not ts: return ""
    try:
        ts = float(ts)
        if ts > 100000000000: ts = ts / 1000
        dt = datetime.fromtimestamp(ts)
        now = datetime.now()
        
        diff = (now - dt).total_seconds()
        
        if 0 <= diff <= (4 * 3600):
            return f"[COLOR red]LIVE[/COLOR] [{dt.strftime('%H:%M')}] "
        
        if dt.date() == now.date():
            return f"[{dt.strftime('%H:%M')}] "
        if dt.date() == (now + timedelta(days=1)).date():
            return f"Tomorrow [{dt.strftime('%H:%M')}] "
        return f"{dt.strftime('%a')} [{dt.strftime('%H:%M')}] "
    except: return ""

def is_match_live(start_ts):
    """Checks if a match is currently live."""
    if start_ts == 0: return True 
    try:
        ts = float(start_ts)
        if ts > 100000000000: ts = ts / 1000
        dt = datetime.fromtimestamp(ts)
        now = datetime.now()
        diff = (now - dt).total_seconds()
        return 0 <= diff <= (4 * 3600)
    except:
        return False

def get_processed_sports():
    """Fetches sports and applies renaming rules."""
    sports = get_sports_list()
    if not sports: return []
    for sport in sports:
        if sport.get('id') == 'fight':
            sport['name'] = 'Boxing-MMA-Wrassling'
    return sports

def normalize_name(name):
    """Normalize string for fuzzy matching."""
    if not name: return ""
    return name.lower().strip().replace('-', ' ').replace('_', ' ')

def find_match_in_data(data, match_id, sport_name):
    """Helper to find a specific match object."""
    if not data or 'sports' not in data: return None

    target_match = None
    search_order = []
    
    if sport_name:
        others = []
        target_name_norm = normalize_name(sport_name)
        for s in data.get('sports', []):
            s_name_norm = normalize_name(s['name'])
            is_match = False
            if s['name'].lower() == sport_name.lower(): is_match = True
            elif s_name_norm == target_name_norm: is_match = True
            elif s.get('id') == 'fight' and 'boxing mma' in target_name_norm: is_match = True
            
            if is_match: search_order.append(s)
            else: others.append(s)
        search_order.extend(others)
    else:
        search_order = data.get('sports', [])

    for s in search_order:
        for m in s.get('matches', []):
            if str(m.get('id')) == str(match_id):
                target_match = m
                break
        if target_match: break
        
    return target_match

def verify_stream(url, referer):
    """Checks if a stream is valid."""
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        'Referer': referer if referer else url
    }
    
    response = requests.get(url, headers=headers, timeout=10, verify=False)
    response.raise_for_status()
    
    playlist_content = response.text
    
    if '.png' in playlist_content:
        log("Detected disguised segments (.png), patching to .ts")
        modified_playlist = playlist_content.replace('.png', '.ts')
        encoded_playlist = base64.b64encode(modified_playlist.encode('utf-8')).decode('utf-8')
        play_url = f"data:application/vnd.apple.mpegurl;base64,{encoded_playlist}"
    else:
        play_url = url

    li = xbmcgui.ListItem(path=play_url)
    li.setProperty('inputstream', 'inputstream.adaptive')
    li.setProperty('inputstream.adaptive.manifest_type', 'hls')
    
    ua = headers['User-Agent']
    ref = headers['Referer']
    stream_headers = f'User-Agent={ua}&Referer={ref}'
    
    li.setProperty('inputstream.adaptive.manifest_headers', stream_headers)
    li.setProperty('inputstream.adaptive.stream_headers', stream_headers)
    
    return li

# ==============================================================================
# MENUS
# ==============================================================================

def add_refresh_item():
    """Adds a 'Refresh Data' item to the list."""
    url = build_url({'mode': 'refresh'})
    li = xbmcgui.ListItem(label="[COLOR blue]↻ Refresh Data[/COLOR]")
    li.setInfo('video', {'title': "Refresh Data", 'plot': "Force reload of all schedule data"})
    xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=li, isFolder=False)

def menu_main():
    """Generates the main menu."""
    add_refresh_item()

    li = xbmcgui.ListItem(label="[COLOR red]Live Now[/COLOR]")
    li.setInfo('video', {'title': "Live Now", 'plot': "Show all currently live matches"})
    url = build_url({'mode': 'live_now'})
    xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=li, isFolder=True)

    sports = get_processed_sports()
    if not sports:
        xbmcgui.Dialog().notification(ADDON_NAME, 'Initializing...', xbmcgui.NOTIFICATION_INFO)
        force_refresh()
        return

    for sport in sports:
        url = build_url({'mode': 'matches', 'sport_id': sport['id'], 'sport_name': sport['name']})
        li = xbmcgui.ListItem(label=sport['name'])
        li.setInfo('video', {'title': sport['name'], 'plot': f"Browse {sport['name']} matches"})
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def menu_live_now():
    """Shows all currently live matches."""
    add_refresh_item()
    
    data = get_kodi_data()
    if not data or 'sports' not in data:
        xbmcplugin.endOfDirectory(ADDON_HANDLE)
        return

    show_all = ADDON.getSetting('show_all_matches') == 'true'
    live_matches = []
    
    for sport in data['sports']:
        sport_name = sport['name']
        if sport.get('id') == 'fight': sport_name = 'Boxing-MMA-Wrassling'

        for match in sport.get('matches', []):
            start = match.get('start_time', 0)
            if is_match_live(start):
                if not show_all and not match.get('has_playable_source', False):
                    continue

                match_copy = match.copy()
                match_copy['_sport_name'] = sport_name
                live_matches.append(match_copy)

    live_matches.sort(key=lambda x: float(x.get('start_time', 0) or 0), reverse=True)

    if not live_matches:
        li = xbmcgui.ListItem(label="No live matches found")
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(ADDON_HANDLE)
        return
    
    for match in live_matches:
        title = match.get('title', 'Unknown Match')
        sport_name = match.get('_sport_name')
        match_id = match.get('id')
        poster = match.get('poster')
        start_time = match.get('start_time')
        
        has_source = match.get('has_playable_source', False)
        color = "white" if has_source else "gray"
        
        if start_time == 0:
            time_str = "[COLOR red]LIVE 24/7[/COLOR] "
        else:
            time_str = format_match_time(start_time)
        
        display_title = f"{time_str}[{sport_name}] [COLOR {color}]{title}[/COLOR]"
        
        url = build_url({
            'mode': 'streams', 
            'match_id': match_id,
            'sport_name': sport_name 
        })
        
        li = xbmcgui.ListItem(label=display_title)
        if poster and poster.startswith('http'):
            li.setArt({'thumb': poster, 'icon': poster, 'fanart': poster})
        
        li.setInfo('video', {'title': title, 'plot': title})
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def menu_matches(sport_id, sport_name):
    """Generates the list of matches for a selected sport."""
    add_refresh_item()
    
    data = get_kodi_data()
    if not data or 'sports' not in data:
        xbmcplugin.endOfDirectory(ADDON_HANDLE)
        return

    show_all = ADDON.getSetting('show_all_matches') == 'true'
    target_sport = None
    clean_sport_id = str(sport_id) if sport_id and str(sport_id).lower() != 'none' else None
    
    if clean_sport_id:
        for s in data['sports']:
            s_id = str(s.get('id')) if s.get('id') else None
            if s_id and s_id == clean_sport_id:
                target_sport = s; break
    
    if not target_sport:
        target_name_norm = normalize_name(sport_name)
        for s in data['sports']:
            s_name_norm = normalize_name(s['name'])
            if s['name'].lower() == sport_name.lower(): target_sport = s; break
            if s_name_norm == target_name_norm: target_sport = s; break
            if s.get('id') == 'fight' and 'boxing mma' in target_name_norm: target_sport = s; break
    
    if not target_sport or not target_sport.get('matches'):
        li = xbmcgui.ListItem(label="No matches found")
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(ADDON_HANDLE)
        return

    now_ts = datetime.now().timestamp()
    cutoff_ts = now_ts - (4 * 3600)
    
    valid_matches = []
    matches_247 = []
    
    for match in target_sport['matches']:
        start = match.get('start_time', 0)
        
        if start == 0:
            if not show_all and not match.get('has_playable_source', False): continue
            matches_247.append(match)
            continue
            
        try:
            ts_val = float(start)
            if ts_val > 100000000000: ts_val = ts_val / 1000
            if ts_val < cutoff_ts: continue

            if is_match_live(ts_val):
                if not show_all and not match.get('has_playable_source', False):
                    continue
            
            valid_matches.append(match)
        except: pass

    live_now = []
    upcoming = []
    
    for m in valid_matches:
        start_t = float(m.get('start_time', 0))
        if start_t > 100000000000: start_t /= 1000
        if is_match_live(start_t):
            live_now.append(m)
        else:
            upcoming.append(m)

    live_now.sort(key=lambda x: float(x.get('start_time', 0) or 0), reverse=True)
    upcoming.sort(key=lambda x: float(x.get('start_time', 0) or 0))
    
    all_display_matches = matches_247 + live_now + upcoming

    if not all_display_matches:
        li = xbmcgui.ListItem(label="No upcoming matches")
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(ADDON_HANDLE)
        return

    for match in all_display_matches:
        title = match.get('title', 'Unknown Match')
        match_id = match.get('id')
        poster = match.get('poster')
        start_time = match.get('start_time')
        
        has_source = match.get('has_playable_source', False)
        color = "white" if has_source else "gray"
        
        if start_time == 0:
            time_str = "[COLOR red]LIVE 24/7[/COLOR] "
        else:
            time_str = format_match_time(start_time)
        
        display_title = f"{time_str}[COLOR {color}]{title}[/COLOR]"
        
        url = build_url({
            'mode': 'streams', 
            'match_id': match_id,
            'sport_name': sport_name
        })
        
        li = xbmcgui.ListItem(label=display_title)
        if poster and poster.startswith('http'):
            li.setArt({'thumb': poster, 'icon': poster, 'fanart': poster})
        
        li.setInfo('video', {'title': title, 'plot': title})
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def menu_streams(match_id, sport_name):
    """Generates the list of available streams for a specific match."""
    data = get_kodi_data()
    if not data or 'sports' not in data:
        xbmcplugin.endOfDirectory(ADDON_HANDLE)
        return

    target_match = find_match_in_data(data, match_id, sport_name)
    if not target_match:
        xbmcgui.Dialog().notification(ADDON_NAME, 'Match data not found', xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(ADDON_HANDLE)
        return

    all_streams = target_match.get('streams', [])
    playable_streams = []

    for stream in all_streams:
        if stream.get('media_url') or stream.get('direct_url'):
            playable_streams.append(stream)

    if not playable_streams:
        li = xbmcgui.ListItem(label="No ready streams available yet")
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(ADDON_HANDLE)
        return

    for i, stream in enumerate(playable_streams, 1):
        media_url = stream.get('media_url') or stream.get('direct_url')
        embed_url = stream.get('url')
        
        # [UPDATED] Added Viewer Count to Label
        viewers = stream.get('viewers', 0)
        label = f"Stream {i} [COLOR gray]({viewers} viewers)[/COLOR]"

        url_params = {
            'mode': 'play',
            'url': media_url,
            'playable': 'true',
            'referer': embed_url
        }
        url = build_url(url_params)
        
        li = xbmcgui.ListItem(label=label)
        li.setInfo('video', {'title': label})
        li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def play_video(url, playable, referer):
    """Handles playback (manual selection)."""
    if playable == 'true':
        try:
            log(f"Attempting playback for: {url}")
            li = verify_stream(url, referer)
            xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, li)
        except Exception as e:
            log(f"Playback failed: {e}", xbmc.LOGERROR)
            xbmcgui.Dialog().ok(ADDON_NAME, f"Playback Failed:\n{str(e)}")
            xbmcplugin.setResolvedUrl(ADDON_HANDLE, False, xbmcgui.ListItem())
    else:
        xbmcgui.Dialog().notification(ADDON_NAME, "Stream Extraction Pending...", xbmcgui.NOTIFICATION_WARNING)
        xbmcplugin.setResolvedUrl(ADDON_HANDLE, False, xbmcgui.ListItem())

def router(param_string):
    """Routing logic based on URL parameters."""
    params = dict(urllib.parse.parse_qsl(param_string))
    mode = params.get('mode')

    if mode is None:
        menu_main()
    elif mode == 'matches':
        menu_matches(params.get('sport_id'), params.get('sport_name'))
    elif mode == 'streams':
        menu_streams(params.get('match_id'), params.get('sport_name'))
    elif mode == 'play':
        play_video(params.get('url'), params.get('playable'), params.get('referer'))
    elif mode == 'live_now':
        menu_live_now()
    elif mode == 'refresh':
        force_refresh()

if __name__ == '__main__':
    router(sys.argv[2][1:])