import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import sys
import os
import urllib.parse
import requests
import json
import time
import base64
import re
from urllib.parse import parse_qsl, urlencode
from datetime import datetime, timedelta

try:
    from resources.lib.api_client import APIClient
    from resources.lib.cache_helper import CacheHelper
    xbmc.log("StreamedEZ: Successfully imported API client and cache helper from resources.lib", xbmc.LOGINFO)
except ImportError as e:
    xbmc.log(f"StreamedEZ: Import error: {str(e)}", xbmc.LOGERROR)
    try:
        from api_client import APIClient
        from cache_helper import CacheHelper
        xbmc.log("StreamedEZ: Successfully imported modules directly", xbmc.LOGINFO)
    except ImportError:
        xbmc.log("StreamedEZ: Failed to import required modules", xbmc.LOGERROR)
        class APIClient:
            def __init__(self, base_url): 
                self.base_url = base_url
                xbmc.log("StreamedEZ: Using dummy APIClient", xbmc.LOGWARNING)
            def get_sports(self): return None
            def get_matches(self): return None
            def get_streams(self): return None
        
        class CacheHelper:
            def __init__(self): 
                xbmc.log("StreamedEZ: Using dummy CacheHelper", xbmc.LOGWARNING)
            def get(self, cache_key): return None
            def set(self, cache_key, data, ttl_hours=24): return True
            def clear(self, cache_key=None): pass

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_NAME = ADDON.getAddonInfo('name')  # This will now be "StreamedEZ"
ADDON_VERSION = ADDON.getAddonInfo('version')
ADDON_HANDLE = int(sys.argv[1])

BRIDGE_API_URL = ADDON.getSetting('api_bridge_url') or 'http://localhost:5000'

api_client = APIClient(BRIDGE_API_URL)
cache_helper = CacheHelper()

def log(msg, level=xbmc.LOGINFO):
    xbmc.log(f"StreamedEZ: {msg}", level)

def get_url(**kwargs):
    return f'{sys.argv[0]}?{urlencode(kwargs)}'

def get_sports_data(force_refresh=False):
    if not force_refresh:
        cached = cache_helper.get('sports')
        if cached:
            log("Using cached sports data", xbmc.LOGINFO)
            return cached
    
    try:
        api_data = api_client.get_sports()
        if api_data:
            sports_data = api_data.get('data', api_data)
            ttl_hours = int(ADDON.getSetting('sports_cache_ttl') or 24)
            cache_helper.set('sports', sports_data, ttl_hours)
            return sports_data
    except Exception as e:
        log(f"Error fetching sports data: {str(e)}", xbmc.LOGERROR)
    return None

def get_matches_data(force_refresh=False):
    if not force_refresh:
        cached = cache_helper.get('matches')
        if cached:
            log("Using cached matches data", xbmc.LOGINFO)
            return cached
    
    try:
        api_data = api_client.get_matches()
        if api_data:
            matches_data = api_data.get('data', api_data)
            ttl_hours = int(ADDON.getSetting('matches_cache_ttl') or 6)
            cache_helper.set('matches', matches_data, ttl_hours)
            return matches_data
    except Exception as e:
        log(f"Error fetching matches data: {str(e)}", xbmc.LOGERROR)
    return None

def get_streams_data(force_refresh=False):
    if not force_refresh:
        cached = cache_helper.get('streams')
        if cached:
            log("Using cached streams data", xbmc.LOGINFO)
            return cached
    
    try:
        api_data = api_client.get_streams()
        if api_data:
            streams_data = api_data.get('data', api_data)
            ttl_minutes = int(ADDON.getSetting('streams_cache_ttl') or 30)
            ttl_hours = ttl_minutes / 60.0
            cache_helper.set('streams', streams_data, ttl_hours)
            return streams_data
    except Exception as e:
        log(f"Error fetching streams data: {str(e)}", xbmc.LOGERROR)
    return None

def get_embed_url(match_id, source):
    return f"https://embedsports.top/embed/{source}/{match_id}/1"

def get_stream_url_from_data(streams_data, match_id, source):
    if not streams_data:
        return None
    for entry in streams_data.get('streams', []):
        if entry.get('id') == match_id:
            for src in entry.get('sources', []):
                if src.get('source') == source and src.get('stream_url'):
                    log(f"Found stream URL for {match_id}/{source}", xbmc.LOGINFO)
                    return src.get('stream_url')
            break
    return None

def get_match_status(match_timestamp):
    """Determine match status based on timestamp"""
    current_time = time.time()
    
    # Convert timestamp to seconds if it's in milliseconds
    if match_timestamp > 1_000_000_000_000:
        match_timestamp = match_timestamp // 1000
    
    time_diff = current_time - match_timestamp
    
    if time_diff < 0:
        return "UPCOMING"
    elif 0 <= time_diff <= (4 * 3600):  # Within 4 hours of start
        return "LIVE"
    else:
        return "FINISHED"

def format_match_time(timestamp):
    """Format timestamp to user-friendly date and time"""
    if timestamp and timestamp > 1_000_000_000_000:
        timestamp = timestamp // 1000
    
    if not timestamp:
        return "Time TBD"
    
    try:
        dt = datetime.fromtimestamp(timestamp)
        # Format: "Fri, Oct 25 - 07:30 PM"
        return dt.strftime("%a, %b %d - %I:%M %p")
    except:
        return "Time TBD"

def play_stream_with_headers(stream_url, embed_url, source, match_id):
    try:
        log("Starting stream playback")
        
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Referer': embed_url
        }
        
        log(f"Fetching playlist from: {stream_url}")
        response = requests.get(stream_url, headers=headers, timeout=10)
        response.raise_for_status()
        playlist_content = response.text
        log(f"Got playlist, length: {len(playlist_content)}")
        
        modified_playlist = re.sub(r'\.png\?', '.ts?', playlist_content)
        log("Modified playlist content")
        
        encoded_playlist = base64.b64encode(modified_playlist.encode('utf-8')).decode('utf-8')
        data_url = f"data:application/vnd.apple.mpegurl;base64,{encoded_playlist}"
        
        log("Created data URL with modified playlist")
        
        list_item = xbmcgui.ListItem(path=stream_url)
        
        list_item.setProperty('inputstream', 'inputstream.adaptive')
        list_item.setProperty('inputstream.adaptive.manifest_type', 'hls')
        
        list_item.setProperty('inputstream.adaptive.manifest_headers', 
                             f'User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36&Referer={embed_url}')
        list_item.setProperty('inputstream.adaptive.stream_headers', 
                             f'User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36&Referer={embed_url}')
        
        list_item.setInfo('video', {
            'title': f'{source.upper()} Stream - {match_id}',
            'plot': f'Live stream from {source} provider'
        })
        
        list_item.setContentLookup(False)
        
        log("Starting playback with original URL and headers")
        
        xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, list_item)
        
        log("Playback ended")
            
    except requests.exceptions.Timeout:
        log("Stream connection timeout", xbmc.LOGERROR)
        xbmcgui.Dialog().notification(ADDON_NAME, 'Stream connection timeout', xbmcgui.NOTIFICATION_ERROR)
    except requests.exceptions.RequestException as e:
        log(f"Network error: {str(e)}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification(ADDON_NAME, f'Network error: {str(e)}', xbmcgui.NOTIFICATION_ERROR)
    except Exception as e:
        log(f"Playback error: {str(e)}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification(ADDON_NAME, f'Playback error: {str(e)}', xbmcgui.NOTIFICATION_ERROR)

def play_stream(params):
    match_id = params.get('match_id', '')
    source = params.get('source', '')

    if not match_id or not source:
        xbmcgui.Dialog().ok(ADDON_NAME, 'Missing required parameters: match_id and source')
        return

    embed_url = get_embed_url(match_id, source)
    log(f"Starting playback for {match_id} from {source}", xbmc.LOGINFO)

    xbmc.executebuiltin('ActivateWindow(busydialognocancel)')

    try:
        # First try with cached streams data
        streams_data = get_streams_data()
        stream_url = get_stream_url_from_data(streams_data, match_id, source)
        
        # If not found, refresh streams data and try again
        if not stream_url:
            log("Stream URL not found in cache, refreshing streams data", xbmc.LOGINFO)
            cache_helper.clear('streams')
            streams_data = get_streams_data(force_refresh=True)
            stream_url = get_stream_url_from_data(streams_data, match_id, source)
        
        if stream_url:
            xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
            play_stream_with_headers(stream_url, embed_url, source, match_id)
        else:
            xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
            xbmcgui.Dialog().ok(ADDON_NAME, f'No Stream URL found\n\nVisit in your browser:\n{embed_url}')

    except Exception as e:
        xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
        log(f"Playback error: {str(e)}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok(ADDON_NAME, f'Playback error: {str(e)}')

def list_sports():
    try:
        sports_data = get_sports_data()
        if not sports_data:
            xbmcgui.Dialog().notification(ADDON_NAME, 'No sports data available', xbmcgui.NOTIFICATION_WARNING, 3000)
            return

        sports_list = sports_data.get('sports', [])
        log(f"Displaying {len(sports_list)} sports", xbmc.LOGINFO)

        for sport in sports_list:
            sport_id = sport.get('id', '')
            sport_name = sport.get('name', 'Unknown Sport')

            list_item = xbmcgui.ListItem(label=sport_name)
            list_item.setArt({'icon': 'icon.png', 'fanart': 'fanart.jpg'})
            list_item.setInfo('video', {'title': sport_name, 'plot': f'Matches for {sport_name}'})

            context_menu = [
                ('Refresh All Data', f'RunPlugin({get_url(action="refresh_all")})'),
                ('Refresh Sports', f'RunPlugin({get_url(action="refresh_sports")})'),
                ('Refresh Matches', f'RunPlugin({get_url(action="refresh_matches")})'),
                ('Refresh Streams', f'RunPlugin({get_url(action="refresh_streams")})')
            ]
            list_item.addContextMenuItems(context_menu)

            list_item.setIsFolder(True)
            url = get_url(action='list_matches', sport_id=sport_id)
            xbmcplugin.addDirectoryItem(ADDON_HANDLE, url, list_item, True)

    except Exception as e:
        log(f"Error listing sports: {str(e)}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification(ADDON_NAME, 'Error loading sports', xbmcgui.NOTIFICATION_ERROR, 3000)

    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def list_matches(sport_id):
    try:
        matches_data = get_matches_data()
        if not matches_data:
            xbmcgui.Dialog().notification(ADDON_NAME, 'No matches data available', xbmcgui.NOTIFICATION_WARNING, 3000)
            return

        all_matches = matches_data.get('matches', [])
        sports_data = get_sports_data() or {}
        sport_name = "Unknown"
        for sport in sports_data.get('sports', []):
            if sport.get('id') == sport_id:
                sport_name = sport.get('name', 'Unknown')
                break

        # Filter matches by sport and remove old matches (finished more than 4 hours ago)
        current_time = time.time()
        filtered_matches = []
        
        for match in all_matches:
            if match.get('category', '').lower() != (sport_id or '').lower():
                continue
                
            timestamp = match.get('date', 0)
            if timestamp and timestamp > 1_000_000_000_000:
                timestamp = timestamp // 1000
                
            # Only show matches that are upcoming, live, or finished within last 4 hours
            if timestamp and (timestamp > (current_time - 4 * 3600)):
                filtered_matches.append(match)

        log(f"Displaying {len(filtered_matches)} matches for {sport_name}", xbmc.LOGINFO)

        if not filtered_matches:
            list_item = xbmcgui.ListItem(label="No upcoming or live matches available")
            list_item.setArt({'icon': 'icon.png', 'fanart': 'fanart.jpg'})
            list_item.setInfo('video', {'title': 'No Matches', 'plot': 'No upcoming or live matches found for this sport'})
            list_item.setIsFolder(False)
            xbmcplugin.addDirectoryItem(ADDON_HANDLE, '', list_item, False)
            xbmcplugin.endOfDirectory(ADDON_HANDLE)
            return

        # Group matches by date
        matches_by_date = {}
        for match in filtered_matches:
            timestamp = match.get('date', 0)
            if timestamp and timestamp > 1_000_000_000_000:
                timestamp = timestamp // 1000
            
            if timestamp:
                match_date = datetime.fromtimestamp(timestamp).strftime("%Y-%m-%d")
                if match_date not in matches_by_date:
                    matches_by_date[match_date] = []
                matches_by_date[match_date].append(match)
            else:
                # Matches without timestamp go to "Unknown Date"
                if "unknown" not in matches_by_date:
                    matches_by_date["unknown"] = []
                matches_by_date["unknown"].append(match)

        # Sort dates chronologically
        sorted_dates = sorted([date for date in matches_by_date.keys() if date != "unknown"])
        if "unknown" in matches_by_date:
            sorted_dates.append("unknown")

        # Display matches grouped by date
        for date_key in sorted_dates:
            date_matches = matches_by_date[date_key]
            
            # Create date header
            if date_key == "unknown":
                date_display = "Date TBD"
            else:
                date_obj = datetime.strptime(date_key, "%Y-%m-%d")
                date_display = date_obj.strftime("%A, %B %d, %Y")
            
            # Add date header as a non-selectable item
            header_item = xbmcgui.ListItem(label=f"[B]{date_display}[/B]")
            header_item.setArt({'icon': 'icon.png', 'fanart': 'fanart.jpg'})
            header_item.setInfo('video', {'title': date_display})
            header_item.setProperty('IsPlayable', 'false')
            xbmcplugin.addDirectoryItem(ADDON_HANDLE, '', header_item, False)
            
            # Add matches for this date
            for match in date_matches:
                match_id = match.get('id', '')
                match_title = match.get('title', 'Unknown Match')
                description = match.get('title', '')
                timestamp = match.get('date', 0)

                # Get match status and format time
                status = get_match_status(timestamp)
                time_display = format_match_time(timestamp)
                
                # Create status indicator with colors
                if status == "LIVE":
                    status_indicator = f"[COLOR red]● LIVE[/COLOR]"
                elif status == "UPCOMING":
                    status_indicator = f"[COLOR green]▶ UPCOMING[/COLOR]"
                else:
                    status_indicator = f"[COLOR gray]■ FINISHED[/COLOR]"
                
                # Build title with status and time
                title = f"{status_indicator} {time_display} - {match_title}"

                list_item = xbmcgui.ListItem(label=title)
                list_item.setArt({'icon': 'icon.png', 'fanart': 'fanart.jpg'})
                list_item.setInfo('video', {
                    'title': title.replace('[COLOR red]', '').replace('[COLOR green]', '').replace('[COLOR gray]', '').replace('[/COLOR]', ''),
                    'plot': description, 
                    'genre': 'Sports'
                })

                context_menu = [
                    ('Refresh Match Data', f'RunPlugin({get_url(action="refresh_matches")})')
                ]
                list_item.addContextMenuItems(context_menu)

                list_item.setIsFolder(True)
                url = get_url(action='list_sources', match_id=match_id)
                xbmcplugin.addDirectoryItem(ADDON_HANDLE, url, list_item, True)

    except Exception as e:
        log(f"Error listing matches: {str(e)}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification(ADDON_NAME, 'Error loading matches', xbmcgui.NOTIFICATION_ERROR, 3000)

    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def list_sources(match_id):
    try:
        streams_data = get_streams_data()
        if not streams_data:
            xbmcgui.Dialog().notification(ADDON_NAME, 'No streams data available', xbmcgui.NOTIFICATION_WARNING, 3000)
            return

        match_entry = None
        for entry in streams_data.get('streams', []):
            if entry.get('id') == match_id:
                match_entry = entry
                break

        if not match_entry:
            xbmcgui.Dialog().notification(ADDON_NAME, 'No sources found for this match', xbmcgui.NOTIFICATION_WARNING, 3000)
            return

        sources = match_entry.get('sources', [])
        log(f"Displaying {len(sources)} sources for match {match_id}", xbmc.LOGINFO)

        for source in sources:
            source_id = source.get('source', '')
            quality = source.get('quality', 'Unknown')
            language = source.get('language', 'Unknown')
            embed_url = source.get('embedUrl', '')
            stream_url = source.get('stream_url', '')

            title = f"{source_id.upper()} - {quality}"
            if language and language != 'Unknown':
                title = f"{title} ({language})"

            list_item = xbmcgui.ListItem(label=title)
            list_item.setArt({'icon': 'icon.png', 'fanart': 'fanart.jpg'})
            list_item.setInfo('video', {'title': title, 'plot': f'Stream from {source_id} provider in {quality} quality'})

            context_menu = [
                ('Refresh Stream Data', f'RunPlugin({get_url(action="refresh_streams")})')
            ]
            list_item.addContextMenuItems(context_menu)

            list_item.setIsFolder(False)
            url = get_url(action='play_stream', match_id=match_id, source=source_id)
            xbmcplugin.addDirectoryItem(ADDON_HANDLE, url, list_item, False)

    except Exception as e:
        log(f"Error listing sources: {str(e)}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification(ADDON_NAME, 'Error loading sources', xbmcgui.NOTIFICATION_ERROR, 3000)

    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def refresh_all_data():
    try:
        log("Refreshing all data", xbmc.LOGINFO)
        xbmcgui.Dialog().notification(ADDON_NAME, 'Refreshing all data...', xbmcgui.NOTIFICATION_INFO, 3000)
        cache_helper.clear()
        get_sports_data(force_refresh=True)
        get_matches_data(force_refresh=True)
        get_streams_data(force_refresh=True)
        xbmcgui.Dialog().notification(ADDON_NAME, 'All data refreshed successfully', xbmcgui.NOTIFICATION_INFO, 3000)
    except Exception as e:
        log(f"Error refreshing all data: {str(e)}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification(ADDON_NAME, 'Error refreshing data', xbmcgui.NOTIFICATION_ERROR, 3000)

def refresh_sports_data():
    try:
        log("Refreshing sports data", xbmc.LOGINFO)
        xbmcgui.Dialog().notification(ADDON_NAME, 'Refreshing sports data...', xbmcgui.NOTIFICATION_INFO, 3000)
        cache_helper.clear('sports')
        get_sports_data(force_refresh=True)
        xbmcgui.Dialog().notification(ADDON_NAME, 'Sports data refreshed successfully', xbmcgui.NOTIFICATION_INFO, 3000)
    except Exception as e:
        log(f"Error refreshing sports data: {str(e)}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification(ADDON_NAME, 'Error refreshing sports data', xbmcgui.NOTIFICATION_ERROR, 3000)

def refresh_matches_data():
    try:
        log("Refreshing matches data", xbmc.LOGINFO)
        xbmcgui.Dialog().notification(ADDON_NAME, 'Refreshing matches data...', xbmcgui.NOTIFICATION_INFO, 3000)
        cache_helper.clear('matches')
        get_matches_data(force_refresh=True)
        xbmcgui.Dialog().notification(ADDON_NAME, 'Matches data refreshed successfully', xbmcgui.NOTIFICATION_INFO, 3000)
    except Exception as e:
        log(f"Error refreshing matches data: {str(e)}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification(ADDON_NAME, 'Error refreshing matches data', xbmcgui.NOTIFICATION_ERROR, 3000)

def refresh_streams_data():
    try:
        log("Refreshing streams data", xbmc.LOGINFO)
        xbmcgui.Dialog().notification(ADDON_NAME, 'Refreshing streams data...', xbmcgui.NOTIFICATION_INFO, 3000)
        cache_helper.clear('streams')
        get_streams_data(force_refresh=True)
        xbmcgui.Dialog().notification(ADDON_NAME, 'Streams data refreshed successfully', xbmcgui.NOTIFICATION_INFO, 3000)
    except Exception as e:
        log(f"Error refreshing streams data: {str(e)}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification(ADDON_NAME, 'Error refreshing streams data', xbmcgui.NOTIFICATION_ERROR, 3000)

def router(paramstring):
    params = dict(parse_qsl(paramstring))
    log(f"Router called with params: {params}", xbmc.LOGDEBUG)
    action = params.get('action', 'list_sports')
    if action == 'play_stream':
        play_stream(params)
    elif action == 'list_matches':
        list_matches(params.get('sport_id'))
    elif action == 'list_sources':
        list_sources(params.get('match_id'))
    elif action == 'refresh_all':
        refresh_all_data()
    elif action == 'refresh_sports':
        refresh_sports_data()
    elif action == 'refresh_matches':
        refresh_matches_data()
    elif action == 'refresh_streams':
        refresh_streams_data()
    else:
        list_sports()

if __name__ == '__main__':
    router(sys.argv[2][1:])