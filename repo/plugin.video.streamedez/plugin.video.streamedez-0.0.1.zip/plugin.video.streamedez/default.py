import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import sys
import os
import urllib.parse
import requests
import json
import time
import base64
import re
import certifi
from urllib.parse import parse_qsl, urlencode
from datetime import datetime, timedelta

try:
    from resources.lib.api_client import APIClient
    from resources.lib.cache_helper import CacheHelper
    xbmc.log("StreamedEZ: Successfully imported API client and cache helper from resources.lib", xbmc.LOGINFO)
except ImportError as e:
    xbmc.log(f"StreamedEZ: Import error: {str(e)}", xbmc.LOGERROR)
    try:
        from api_client import APIClient
        from cache_helper import CacheHelper
        xbmc.log("StreamedEZ: Successfully imported modules directly", xbmc.LOGINFO)
    except ImportError:
        xbmc.log("StreamedEZ: Failed to import required modules", xbmc.LOGERROR)
        class APIClient:
            def __init__(self, base_url): 
                self.base_url = base_url
                xbmc.log("StreamedEZ: Using dummy APIClient", xbmc.LOGWARNING)
            def get_sports(self): return None
            def get_matches(self): return None
            def get_streams(self): return None
        
        class CacheHelper:
            def __init__(self): 
                xbmc.log("StreamedEZ: Using dummy CacheHelper", xbmc.LOGWARNING)
            def get(self, cache_key): return None
            def set(self, cache_key, data, ttl_hours=24): return True
            def clear(self, cache_key=None): pass

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_NAME = ADDON.getAddonInfo('name')
ADDON_VERSION = ADDON.getAddonInfo('version')
ADDON_HANDLE = int(sys.argv[1])

BRIDGE_API_URL = ADDON.getSetting('api_bridge_url')

api_client = APIClient(BRIDGE_API_URL)
cache_helper = CacheHelper()

def log(msg, level=xbmc.LOGINFO):
    xbmc.log(f"StreamedEZ: {msg}", level)

def get_url(**kwargs):
    return f'{sys.argv[0]}?{urlencode(kwargs)}'

# --- Data fetch helpers (sports, matches, streams) ---
def get_sports_data(force_refresh=False):
    if not force_refresh:
        cached = cache_helper.get('sports')
        if cached:
            log("Using cached sports data", xbmc.LOGINFO)
            return cached
    try:
        api_data = api_client.get_sports()
        if api_data:
            sports_data = api_data.get('data', api_data)
            ttl_hours = int(ADDON.getSetting('sports_cache_ttl') or 24)
            cache_helper.set('sports', sports_data, ttl_hours)
            return sports_data
    except Exception as e:
        log(f"Error fetching sports data: {str(e)}", xbmc.LOGERROR)
    return None

def get_matches_data(force_refresh=False):
    if not force_refresh:
        cached = cache_helper.get('matches')
        if cached:
            log("Using cached matches data", xbmc.LOGINFO)
            return cached
    try:
        api_data = api_client.get_matches()
        if api_data:
            matches_data = api_data.get('data', api_data)
            ttl_hours = int(ADDON.getSetting('matches_cache_ttl') or 6)
            cache_helper.set('matches', matches_data, ttl_hours)
            return matches_data
    except Exception as e:
        log(f"Error fetching matches data: {str(e)}", xbmc.LOGERROR)
    return None

def get_streams_data(force_refresh=False):
    if not force_refresh:
        cached = cache_helper.get('streams')
        if cached:
            log("Using cached streams data", xbmc.LOGINFO)
            return cached
    try:
        api_data = api_client.get_streams()
        if api_data:
            streams_data = api_data.get('data', api_data)
            ttl_minutes = int(ADDON.getSetting('streams_cache_ttl') or 30)
            ttl_hours = ttl_minutes / 60.0
            cache_helper.set('streams', streams_data, ttl_hours)
            return streams_data
    except Exception as e:
        log(f"Error fetching streams data: {str(e)}", xbmc.LOGERROR)
    return None

# --- Playback helpers ---
def get_embed_url(match_id, source):
    return f"https://embedsports.top/embed/{source}/{match_id}/1"

def get_media_url_from_data(streams_data, match_id, source):
    if not streams_data:
        return None
    for entry in streams_data.get('streams', []):
        if entry.get('id') == match_id:
            for src in entry.get('sources', []):
                if src.get('source') == source and src.get('media_url'):
                    log(f"Found stream URL for {match_id}/{source}", xbmc.LOGINFO)
                    return src.get('media_url')
            break
    return None

def play_stream_with_headers(media_url, embed_url, source, match_id):
    try:
        log("Starting stream playback")
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Referer': embed_url
        }
        log(f"Fetching playlist from: {media_url}")
        response = requests.get(media_url, headers=headers, timeout=10, verify=certifi.where())
        response.raise_for_status()
        playlist_content = response.text
        log(f"Got playlist, length: {len(playlist_content)}")
        modified_playlist = re.sub(r'\.png\?', '.ts?', playlist_content)
        log("Modified playlist content")
        encoded_playlist = base64.b64encode(modified_playlist.encode('utf-8')).decode('utf-8')
        data_url = f"data:application/vnd.apple.mpegurl;base64,{encoded_playlist}"
        log("Created data URL with modified playlist")

        list_item = xbmcgui.ListItem(path=media_url)
        list_item.setProperty('inputstream', 'inputstream.adaptive')
        list_item.setProperty('inputstream.adaptive.manifest_type', 'hls')
        list_item.setProperty('inputstream.adaptive.manifest_headers', 
                             f'User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36&Referer={embed_url}')
        list_item.setProperty('inputstream.adaptive.stream_headers', 
                             f'User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36&Referer={embed_url}')
        list_item.setInfo('video', {
            'title': f'{source.upper()} Stream - {match_id}',
            'plot': f'Live stream from {source} provider'
        })
        list_item.setContentLookup(False)
        log("Starting playback with original URL and headers")
        xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, list_item)
        log("Playback ended")
    except requests.exceptions.Timeout:
        log("Stream connection timeout", xbmc.LOGERROR)
        xbmcgui.Dialog().notification(ADDON_NAME, 'Stream connection timeout', xbmcgui.NOTIFICATION_ERROR)
    except requests.exceptions.RequestException as e:
        log(f"Network error: {str(e)}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification(ADDON_NAME, f'Network error: {str(e)}', xbmcgui.NOTIFICATION_ERROR)
    except Exception as e:
        log(f"Playback error: {str(e)}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification(ADDON_NAME, f'Playback error: {str(e)}', xbmcgui.NOTIFICATION_ERROR)

# --- Router ---
def play_stream(params):
    match_id = params.get('match_id', '')
    source = params.get('source', '')
    if not match_id or not source:
        xbmcgui.Dialog().