import xbmc
import requests
import json

class APIClient:
    def __init__(self, base_url):
        self.base_url = base_url.rstrip('/')
        self.timeout = 30
    
    def _make_request(self, endpoint, method='GET', data=None, params=None):
        try:
            url = f"{self.base_url}/{endpoint.lstrip('/')}"
            xbmc.log(f"StreamedEZ: API Request: {url}", xbmc.LOGINFO)
            
            if method == 'POST':
                response = requests.post(url, json=data, timeout=self.timeout)
            else:
                response = requests.get(url, params=params, timeout=self.timeout)
            
            response.raise_for_status()
            return response.json()
        except Exception as e:
            xbmc.log(f"StreamedEZ: API Request failed: {str(e)}", xbmc.LOGERROR)
            return None
    
    def get_sports(self):
        return self._make_request('full/sports')

    def get_kodi_data(self):
        return self._make_request('kodi/data.json')