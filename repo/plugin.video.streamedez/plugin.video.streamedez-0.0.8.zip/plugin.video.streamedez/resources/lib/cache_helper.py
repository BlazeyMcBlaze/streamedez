import xbmc
import xbmcaddon
import xbmcvfs
import os
import json
import time
from datetime import datetime, timedelta

class CacheHelper:
    def __init__(self):
        self.addon = xbmcaddon.Addon()
        # translatePath is crucial for compatibility across different OS file systems
        profile_path = xbmcvfs.translatePath(self.addon.getAddonInfo('profile'))
        self.cache_dir = os.path.join(profile_path, 'cache')
        
        if not xbmcvfs.exists(self.cache_dir):
            xbmc.log(f"StreamedEZ: Creating cache dir at {self.cache_dir}", xbmc.LOGINFO)
            success = xbmcvfs.mkdirs(self.cache_dir)
            if not success:
                xbmc.log(f"StreamedEZ: FAILED to create cache dir at {self.cache_dir}", xbmc.LOGERROR)
    
    def get(self, cache_key):
        """Retrieves data from cache if it exists and hasn't expired."""
        cache_file = os.path.join(self.cache_dir, f"{cache_key}.json")
        
        if not xbmcvfs.exists(cache_file):
            return None
        
        try:
            with xbmcvfs.File(cache_file, 'r') as f:
                content = f.read()
                cache_data = json.loads(content)
            
            if time.time() > cache_data.get('expires_at', 0):
                xbmcvfs.delete(cache_file)
                return None
            
            return cache_data.get('data')
            
        except Exception as e:
            xbmc.log(f"CacheHelper: Error reading cache {cache_key}: {str(e)}", xbmc.LOGERROR)
            return None
    
    def set(self, cache_key, data, ttl_hours=24):
        """Saves data to cache with a specified time-to-live."""
        cache_file = os.path.join(self.cache_dir, f"{cache_key}.json")
        
        cache_data = {
            'data': data,
            'created_at': time.time(),
            'expires_at': time.time() + (ttl_hours * 3600),
            'created_human': datetime.now().isoformat()
        }
        
        try:
            with xbmcvfs.File(cache_file, 'w') as f:
                f.write(json.dumps(cache_data))
            return True
        except Exception as e:
            xbmc.log(f"CacheHelper: Error writing cache {cache_key}: {str(e)}", xbmc.LOGERROR)
            return False
    
    def clear(self, cache_key=None):
        """Clears a specific cache key or the entire cache directory."""
        if cache_key:
            cache_file = os.path.join(self.cache_dir, f"{cache_key}.json")
            if xbmcvfs.exists(cache_file):
                xbmcvfs.delete(cache_file)
        else:
            dirs, files = xbmcvfs.listdir(self.cache_dir)
            for file in files:
                if file.endswith('.json'):
                    xbmcvfs.delete(os.path.join(self.cache_dir, file))