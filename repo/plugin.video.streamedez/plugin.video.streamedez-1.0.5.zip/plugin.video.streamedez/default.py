import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import sys
import urllib.parse
import requests
import base64
import re
import certifi
import xbmcvfs
import os
from datetime import datetime, timedelta

try:
    from resources.lib.api_client import APIClient
    from resources.lib.cache_helper import CacheHelper
except ImportError:
    from api_client import APIClient
    from cache_helper import CacheHelper

ADDON = xbmcaddon.Addon()
ADDON_NAME = ADDON.getAddonInfo('name')
ADDON_HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]

# -----------------------------------------------------------------------------
# API CONFIGURATION
# -----------------------------------------------------------------------------
# List of API servers to try in order.
# If the first one fails, the addon will attempt the next one.
API_SERVERS = [
    "http://streamedex.hidenmc.com:24670",     # Primary Server
    "http://june.hidencloud.com:24670",      # Backup Server
    "http://fi7.bot-hosting.net:22382"        # Second backup, different host
]

cache_helper = CacheHelper()

def log(msg, level=xbmc.LOGINFO):
    """Wrapper for xbmc logging."""
    xbmc.log(f"StreamedEZ: {msg}", level)

def build_url(query):
    """Constructs the plugin URL with query parameters."""
    return BASE_URL + '?' + urllib.parse.urlencode(query)

def fetch_from_api(method_name):
    """
    Tries to execute an API method across all configured servers.
    Returns the result of the first successful call.
    """
    last_error = None
    
    for url in API_SERVERS:
        try:
            log(f"Connecting to API Server: {url}")
            # Instantiate client for this specific server
            client = APIClient(url)
            
            # Execute the requested method
            if method_name == 'get_sports':
                return client.get_sports()
            elif method_name == 'get_kodi_data':
                return client.get_kodi_data()
            else:
                raise ValueError(f"Unknown API method: {method_name}")
                
        except Exception as e:
            log(f"Connection failed for {url}: {str(e)}", level=xbmc.LOGWARNING)
            last_error = e
            continue # Try next server
            
    # If loop finishes without returning, all servers failed
    log(f"All API servers failed. Last error: {str(last_error)}", level=xbmc.LOGERROR)
    raise last_error if last_error else Exception("No API servers available")

def get_clean_timestamp(match):
    """Helper to safely get normalized timestamp (seconds) from match data."""
    try:
        ts = float(match.get('start_time', 0) or 0)
        # Convert ms to seconds if necessary
        if ts > 100000000000: 
            ts = ts / 1000
        return ts
    except:
        return 0

def get_sports_list():
    """Fetches list of sports, trying cache first then API (with failover)."""
    cached = cache_helper.get('sports_list')
    if cached: return cached
    
    try:
        # Use failover helper
        response = fetch_from_api('get_sports')
        
        if response and 'sports' in response:
            data = response['sports']
            cache_helper.set('sports_list', data, ttl_hours=24)
            return data
            
    except Exception as e:
        xbmcgui.Dialog().ok(ADDON_NAME, f"Failed to load sports list:\nCould not connect to any server.")
        return []
    
    return []

def get_kodi_data():
    """Fetches the main data payload from the API (with failover)."""
    cached = cache_helper.get('kodi_data')
    if cached: return cached
    
    try:
        # Use failover helper
        data = fetch_from_api('get_kodi_data')
        
        if data:
            cache_helper.set('kodi_data', data, ttl_hours=0.08) 
            return data
            
    except Exception as e:
        xbmcgui.Dialog().ok(ADDON_NAME, f"Failed to load match data:\nCould not connect to any server.")
        return None
        
    return None

def format_match_time(ts):
    """Formats timestamp into readable string, handling LIVE status and relative dates."""
    if not ts: return ""
    try:
        ts = float(ts)
        if ts > 100000000000: ts = ts / 1000
        dt = datetime.fromtimestamp(ts)
        now = datetime.now()
        
        diff = (now - dt).total_seconds()
        
        if 0 <= diff <= (4 * 3600):
            return f"[COLOR red]LIVE[/COLOR] [{dt.strftime('%H:%M')}] "
        
        if dt.date() == now.date():
            return f"[{dt.strftime('%H:%M')}] "
        if dt.date() == (now + timedelta(days=1)).date():
            return f"Tomorrow [{dt.strftime('%H:%M')}] "
        return f"{dt.strftime('%a')} [{dt.strftime('%H:%M')}] "
    except: return ""

def is_match_live(start_ts):
    """Checks if a match is currently live based on start timestamp."""
    if start_ts == 0: return True 
    try:
        ts = float(start_ts)
        if ts > 100000000000: ts = ts / 1000
        dt = datetime.fromtimestamp(ts)
        now = datetime.now()
        diff = (now - dt).total_seconds()
        return -1800 <= diff <= (4 * 3600)
    except:
        return False

def is_future_or_grace_period(start_ts, grace_minutes=5):
    """
    Returns True if the match is in the future OR 
    started less than `grace_minutes` ago.
    """
    if not start_ts: return False
    try:
        ts = float(start_ts)
        if ts > 100000000000: ts = ts / 1000
        now_ts = datetime.now().timestamp()
        
        # Calculate seconds since start
        # If match is in future, seconds_since_start is negative
        seconds_since_start = now_ts - ts
        
        # We allow it if it is negative (future) 
        # OR if it is less than grace_minutes * 60
        return seconds_since_start < (grace_minutes * 60)
    except:
        return False

def get_processed_sports():
    """Fetches sports and applies renaming rules. Filters out grouped sports."""
    sports = get_sports_list()
    if not sports: return []
    
    filtered_sports = []
    for sport in sports:
        # Filter: Skip sports that are grouped to 'Other'
        # Robust check for boolean, string "true", or int 1
        raw_val = sport.get('group_to_other', False)
        should_group = False
        
        if isinstance(raw_val, bool):
            should_group = raw_val
        elif isinstance(raw_val, str):
            should_group = raw_val.lower() == 'true'
        elif isinstance(raw_val, int):
            should_group = raw_val == 1
            
        if should_group:
            continue
            
        if sport.get('id') == 'fight':
            sport['name'] = 'Boxing-MMA-Wrassling'
        
        filtered_sports.append(sport)
    return filtered_sports

def normalize_name(name):
    """Normalize string for fuzzy matching (lowercase, no spaces/dashes)."""
    if not name: return ""
    return name.lower().strip().replace('-', ' ').replace('_', ' ')

def find_match_in_data(data, match_id, sport_name):
    """Helper to find a specific match object within the data."""
    if not data or 'sports' not in data:
        return None

    target_match = None
    search_order = []
    
    if sport_name:
        others = []
        target_name_norm = normalize_name(sport_name)
        
        for s in data.get('sports', []):
            s_name_norm = normalize_name(s['name'])
            is_match = False
            
            if s['name'].lower() == sport_name.lower(): is_match = True
            elif s_name_norm == target_name_norm: is_match = True
            elif s.get('id') == 'fight' and 'boxing mma' in target_name_norm: is_match = True
            
            if is_match:
                search_order.append(s)
            else:
                others.append(s)
        search_order.extend(others)
    else:
        search_order = data.get('sports', [])

    for s in search_order:
        for m in s.get('matches', []):
            if str(m.get('id')) == str(match_id):
                target_match = m
                break
        if target_match: break
        
    return target_match

def verify_stream(url, referer):
    """Checks if a stream is valid and returns the ListItem ready for playback."""
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        'Referer': referer if referer else url
    }
    
    response = requests.get(url, headers=headers, timeout=10, verify=False)
    response.raise_for_status()
    
    playlist_content = response.text
    
    if '.png' in playlist_content:
        log("Detected disguised segments (.png), patching to .ts")
        modified_playlist = playlist_content.replace('.png', '.ts')
        encoded_playlist = base64.b64encode(modified_playlist.encode('utf-8')).decode('utf-8')
        play_url = f"data:application/vnd.apple.mpegurl;base64,{encoded_playlist}"
    else:
        play_url = url

    li = xbmcgui.ListItem(path=play_url)
    li.setProperty('inputstream', 'inputstream.adaptive')
    li.setProperty('inputstream.adaptive.manifest_type', 'hls')
    
    ua = headers['User-Agent']
    ref = headers['Referer']
    stream_headers = f'User-Agent={ua}&Referer={ref}'
    
    li.setProperty('inputstream.adaptive.manifest_headers', stream_headers)
    li.setProperty('inputstream.adaptive.stream_headers', stream_headers)
    
    return li

def clear_full_cache():
    """Deletes cache files and forces a refresh."""
    cache_helper.clear()
    xbmcgui.Dialog().notification(ADDON_NAME, 'Cache Cleared Successfully', xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin('Container.Refresh')

def refresh_cache():
    """Manually clears cache and reloads data (Context Menu Action)."""
    cache_helper.clear()
    xbmcgui.Dialog().notification(ADDON_NAME, 'Cache Cleared', xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin('Container.Refresh')

def add_refresh_context_menu(list_item):
    """Adds 'Refresh Data' to the context menu of a list item."""
    refresh_url = build_url({'mode': 'refresh_cache'})
    list_item.addContextMenuItems([('Refresh Data', f'RunPlugin({refresh_url})')])

def menu_main():
    """Generates the main menu listing available sports."""
    li = xbmcgui.ListItem(label="[COLOR red]Live Now[/COLOR]")
    li.setInfo('video', {'title': "Live Now", 'plot': "Show all currently live matches"})
    url = build_url({'mode': 'live_now'})
    add_refresh_context_menu(li)
    xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=li, isFolder=True)

    sports = get_processed_sports()
    if not sports:
        xbmcplugin.endOfDirectory(ADDON_HANDLE)
        return

    for sport in sports:
        url = build_url({'mode': 'matches', 'sport_id': sport['id'], 'sport_name': sport['name']})
        li = xbmcgui.ListItem(label=sport['name'])
        li.setInfo('video', {'title': sport['name'], 'plot': f"Browse {sport['name']} matches"})
        add_refresh_context_menu(li)
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def menu_live_now():
    """Shows all currently live matches across all sports."""
    data = get_kodi_data()
    if not data or 'sports' not in data:
        if not data: 
             xbmcplugin.endOfDirectory(ADDON_HANDLE)
             return
        xbmcgui.Dialog().notification(ADDON_NAME, 'No data available', xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(ADDON_HANDLE)
        return

    # Settings
    show_all = ADDON.getSetting('show_all_matches') == 'true'

    live_matches_to_sort = []
    
    for sport in data['sports']:
        sport_name = sport['name']
        if sport.get('id') == 'fight': 
            sport_name = 'Boxing-MMA-Wrassling'

        for match in sport.get('matches', []):
            start = match.get('start_time', 0)
            
            # Check if match is live (roughly)
            if is_match_live(start):
                # Filter Check: 
                # 1. Has playable source?
                # 2. OR User wants to see everything?
                # 3. OR Game started less than 5 minutes ago (Grace Period)?
                has_playable = match.get('has_playable_source', False)
                # Changed grace_minutes to 0 so unplayable games hide immediately at start time
                in_grace_period = is_future_or_grace_period(start, grace_minutes=0)
                
                if show_all or has_playable or in_grace_period:
                    match_copy = match.copy()
                    match_copy['_sport_name'] = sport_name
                    live_matches_to_sort.append(match_copy)

    # --- Sorting Logic ---
    now_ts = datetime.now().timestamp()
    started_matches = []
    upcoming_matches = []
    
    for m in live_matches_to_sort:
        ts = get_clean_timestamp(m)
        if ts <= now_ts:
            started_matches.append(m)
        else:
            upcoming_matches.append(m)
            
    # Started: Most recent start first (Descending)
    started_matches.sort(key=lambda x: get_clean_timestamp(x), reverse=True)
    
    # Upcoming: Soonest start first (Ascending)
    upcoming_matches.sort(key=lambda x: get_clean_timestamp(x))
    
    # Combined: Started first, then Upcoming
    final_display_list = started_matches + upcoming_matches

    if not final_display_list:
        li = xbmcgui.ListItem(label="No live matches right now")
        add_refresh_context_menu(li)
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(ADDON_HANDLE)
        return
    
    for match in final_display_list:
        title = match.get('title', 'Unknown Match')
        sport_name = match.get('_sport_name')
        match_id = match.get('id')
        poster = match.get('poster')
        start_time = match.get('start_time')
        
        if start_time == 0:
            time_str = "[COLOR red]LIVE 24/7[/COLOR] "
        else:
            time_str = format_match_time(start_time)
        
        display_title = f"{time_str}[{sport_name}] {title}"
        
        # Check playable streams for Auto-Play logic AND Coloring
        raw_streams = match.get('streams', [])
        playable_streams = [s for s in raw_streams if s.get('media_url') or s.get('direct_url')]
        
        # Apply Grey Color if no streams
        if not playable_streams:
            display_title = f"[COLOR gray]{display_title}[/COLOR]"
        
        url_params = {
            'match_id': match_id,
            'sport_name': sport_name 
        }

        # Default: Folder behavior (0 streams)
        is_folder = True
        is_playable = 'false'
        
        # If any stream exists (guaranteed to be 1 max), Play Directly
        if playable_streams:
            stream = playable_streams[0]
            media_url = stream.get('media_url') or stream.get('direct_url')
            embed_url = stream.get('url')
            
            url_params['mode'] = 'play'
            url_params['url'] = media_url
            url_params['playable'] = 'true'
            url_params['referer'] = embed_url
            
            is_folder = False
            is_playable = 'true'
        else:
            # 0 streams -> Open List (to show "No streams" msg)
            url_params['mode'] = 'streams'
        
        url = build_url(url_params)
        
        li = xbmcgui.ListItem(label=display_title)
        if poster and poster.startswith('http'):
            li.setArt({'thumb': poster, 'icon': poster, 'fanart': poster})
        
        li.setInfo('video', {'title': title, 'plot': title})
        if is_playable == 'true':
            li.setProperty('IsPlayable', 'true')
            
        add_refresh_context_menu(li)
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=li, isFolder=is_folder)

    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def menu_matches(sport_id, sport_name):
    """Generates the list of matches for a selected sport."""
    data = get_kodi_data()
    
    if not data or 'sports' not in data:
        if data is None: 
            xbmcplugin.endOfDirectory(ADDON_HANDLE)
            return
        xbmcgui.Dialog().notification(ADDON_NAME, 'No match data available', xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(ADDON_HANDLE)
        return

    # Check 'Other' category aggregation
    is_other_category = False
    if sport_id and str(sport_id).lower() == 'other':
        is_other_category = True
    elif sport_name and sport_name.lower() == 'other':
        is_other_category = True

    target_matches = []
    
    if is_other_category:
        for s in data['sports']:
            # Handle Grouping logic inside the match listing as well
            raw_val = s.get('group_to_other', False)
            should_group = False
            if isinstance(raw_val, bool): should_group = raw_val
            elif isinstance(raw_val, str): should_group = raw_val.lower() == 'true'
            elif isinstance(raw_val, int): should_group = raw_val == 1
            
            is_literal_other = (str(s.get('id', '')).lower() == 'other' or s.get('name', '').lower() == 'other')
            
            if should_group or is_literal_other:
                for m in s.get('matches', []):
                    m_copy = m.copy()
                    if should_group and not is_literal_other:
                        real_sport_name = s.get('name', 'Unknown')
                        original_title = m_copy.get('title', 'Unknown')
                        if not original_title.startswith(f"[{real_sport_name}]"):
                            m_copy['title'] = f"[{real_sport_name}] {original_title}"
                            
                    m_copy['_real_sport_name'] = s.get('name')
                    target_matches.append(m_copy)
    else:
        target_sport = None
        clean_sport_id = str(sport_id) if sport_id and str(sport_id).lower() != 'none' else None
        
        if clean_sport_id:
            for s in data['sports']:
                if str(s.get('id')) == clean_sport_id:
                    target_sport = s; break

        if not target_sport:
            target_name_norm = normalize_name(sport_name)
            for s in data['sports']:
                s_name_norm = normalize_name(s['name'])
                if s['name'].lower() == sport_name.lower(): 
                    target_sport = s; break
                if s_name_norm == target_name_norm: 
                    target_sport = s; break
                if s.get('id') == 'fight' and 'boxing mma' in target_name_norm: 
                    target_sport = s; break
        
        if target_sport:
            target_matches = target_sport.get('matches', [])

    if not target_matches:
        li = xbmcgui.ListItem(label="No matches found")
        add_refresh_context_menu(li)
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(ADDON_HANDLE)
        return

    # Read Settings
    show_all = ADDON.getSetting('show_all_matches') == 'true'
    
    now_ts = datetime.now().timestamp()
    cutoff_ts = now_ts - (4 * 3600)
    
    matches_to_sort = []
    
    for match in target_matches:
        # 1. Filter Check: Time Cutoff (hide games that ended > 4 hours ago)
        start = match.get('start_time', 0)
        
        if start != 0:
            try:
                ts_val = get_clean_timestamp(match)
                if ts_val < cutoff_ts:
                    continue # Too old
            except: pass

        # 2. Filter Check: Streams vs Grace Period
        has_playable = match.get('has_playable_source', False)
        # Changed grace_minutes to 0 so unplayable games hide immediately at start time
        in_grace_period = is_future_or_grace_period(start, grace_minutes=0)
        
        if not show_all and not has_playable and not in_grace_period:
            continue

        matches_to_sort.append(match)

    # --- Sorting Logic ---
    started_matches = []
    upcoming_matches = []
    
    for m in matches_to_sort:
        ts = get_clean_timestamp(m)
        if ts <= now_ts:
            started_matches.append(m)
        else:
            upcoming_matches.append(m)
            
    # Started: Most recent start first (Descending)
    started_matches.sort(key=lambda x: get_clean_timestamp(x), reverse=True)
    
    # Upcoming: Soonest start first (Ascending)
    upcoming_matches.sort(key=lambda x: get_clean_timestamp(x))
    
    # Combined: Started first, then Upcoming
    all_display_matches = started_matches + upcoming_matches

    if not all_display_matches:
        li = xbmcgui.ListItem(label="No upcoming matches")
        add_refresh_context_menu(li)
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(ADDON_HANDLE)
        return

    for match in all_display_matches:
        title = match.get('title', 'Unknown Match')
        match_id = match.get('id')
        poster = match.get('poster')
        start_time = match.get('start_time')
        current_sport_name = match.get('_real_sport_name', sport_name)

        if start_time == 0:
            time_str = "[COLOR red]LIVE 24/7[/COLOR] "
        else:
            time_str = format_match_time(start_time)
        
        display_title = f"{time_str}{title}"
        
        # Check playable streams for Auto-Play logic AND Coloring
        raw_streams = match.get('streams', [])
        playable_streams = [s for s in raw_streams if s.get('media_url') or s.get('direct_url')]
        
        # Apply Grey Color if no streams
        if not playable_streams:
            display_title = f"[COLOR gray]{display_title}[/COLOR]"
        
        url_params = {
            'match_id': match_id,
            'sport_name': current_sport_name
        }

        # Default: Folder behavior (0 streams)
        is_folder = True
        is_playable = 'false'
        
        # If any stream exists (guaranteed to be 1 max), Play Directly
        if playable_streams:
            stream = playable_streams[0]
            media_url = stream.get('media_url') or stream.get('direct_url')
            embed_url = stream.get('url')
            
            url_params['mode'] = 'play'
            url_params['url'] = media_url
            url_params['playable'] = 'true'
            url_params['referer'] = embed_url
            
            is_folder = False
            is_playable = 'true'
        else:
            # 0 streams -> Open List (to show "No streams" msg)
            url_params['mode'] = 'streams'
            
        url = build_url(url_params)
        
        li = xbmcgui.ListItem(label=display_title)
        if poster and poster.startswith('http'):
            li.setArt({'thumb': poster, 'icon': poster, 'fanart': poster})
        
        li.setInfo('video', {'title': title, 'plot': title})
        if is_playable == 'true':
            li.setProperty('IsPlayable', 'true')
        
        add_refresh_context_menu(li)
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=li, isFolder=is_folder)

    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def auto_play(match_id, sport_name):
    """Attempts to play the 1st stream. Fallback to list if it fails."""
    data = get_kodi_data()
    match = find_match_in_data(data, match_id, sport_name)
    
    if not match:
        xbmcgui.Dialog().notification(ADDON_NAME, 'Match not found', xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.setResolvedUrl(ADDON_HANDLE, False, xbmcgui.ListItem())
        return

    streams = match.get('streams', [])
    
    if streams:
        first_stream = streams[0]
        media_url = first_stream.get('media_url') or first_stream.get('direct_url')
        embed_url = first_stream.get('url')
        
        if media_url:
            try:
                log(f"AutoPlay: Testing 1st stream {media_url}")
                li = verify_stream(media_url, embed_url)
                log("AutoPlay: Stream 1 is valid. Playing.")
                xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, li)
                return
            except Exception as e:
                log(f"AutoPlay: Stream 1 failed ({str(e)}). Falling back to list.", xbmc.LOGWARNING)
        else:
            log("AutoPlay: Stream 1 is Web Only. Falling back to list.", xbmc.LOGINFO)
    
    list_url = build_url({
        'mode': 'streams',
        'match_id': match_id,
        'sport_name': sport_name
    })
    xbmc.executebuiltin(f"Container.Update({list_url})")

def menu_streams(match_id, sport_name):
    """Generates the list of available streams for a specific match."""
    data = get_kodi_data()
    if not data or 'sports' not in data:
        xbmcplugin.endOfDirectory(ADDON_HANDLE)
        return

    target_match = find_match_in_data(data, match_id, sport_name)
    
    if not target_match:
        xbmcgui.Dialog().notification(ADDON_NAME, 'Match data not found', xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(ADDON_HANDLE)
        return

    poster = target_match.get('poster')
    raw_streams = target_match.get('streams', [])
    
    # Filter to keep ONLY streams with a valid media_url or direct_url
    playable_streams = [s for s in raw_streams if s.get('media_url') or s.get('direct_url')]

    if not playable_streams:
        li = xbmcgui.ListItem(label="No streams available, check back at game time or refresh data")
        add_refresh_context_menu(li)
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(ADDON_HANDLE)
        return

    for i, stream in enumerate(playable_streams, 1):
        quality = stream.get('quality', 'SD')
        language = stream.get('language', 'En')
        viewers = stream.get('viewers', 0)
        
        media_url = stream.get('media_url') or stream.get('direct_url')
        embed_url = stream.get('url')
        
        label = f"[{quality}] Stream {i} ({language}) - {viewers} Viewers"
        is_playable = 'true'
        play_url = media_url

        url_params = {
            'mode': 'play',
            'url': play_url,
            'playable': is_playable,
            'referer': embed_url
        }
        url = build_url(url_params)
        
        li = xbmcgui.ListItem(label=label)
        li.setInfo('video', {'title': label})
        li.setProperty('IsPlayable', 'true')
        
        if poster and poster.startswith('http'):
            li.setArt({'thumb': poster, 'icon': poster, 'fanart': poster})

        add_refresh_context_menu(li)
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def play_video(url, playable, referer):
    """Handles playback (manual selection)."""
    if playable == 'true':
        try:
            log(f"Attempting playback for: {url}")
            li = verify_stream(url, referer)
            xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, li)

        except requests.exceptions.ConnectionError:
            log("Playback Connection Error", xbmc.LOGERROR)
            xbmcgui.Dialog().ok(ADDON_NAME, "Playback Error:\nCould not connect to the stream source.\nThe server might be offline.")
            xbmcplugin.setResolvedUrl(ADDON_HANDLE, False, xbmcgui.ListItem())

        except requests.exceptions.Timeout:
            log("Playback Timeout", xbmc.LOGERROR)
            xbmcgui.Dialog().ok(ADDON_NAME, "Playback Error:\nConnection to stream timed out.\nYour connection or the server is too slow.")
            xbmcplugin.setResolvedUrl(ADDON_HANDLE, False, xbmcgui.ListItem())

        except requests.exceptions.HTTPError as e:
            log(f"Playback HTTP Error: {e}", xbmc.LOGERROR)
            xbmcgui.Dialog().ok(ADDON_NAME, f"Playback Error:\nServer returned error code {e.response.status_code}.")
            xbmcplugin.setResolvedUrl(ADDON_HANDLE, False, xbmcgui.ListItem())
            
        except Exception as e:
            log(f"Playback failed: {e}", xbmc.LOGERROR)
            xbmcgui.Dialog().ok(ADDON_NAME, f"Playback Failed:\n{str(e)}")
            xbmcplugin.setResolvedUrl(ADDON_HANDLE, False, xbmcgui.ListItem())
    else:
        log(f"User clicked embed URL: {url}", xbmc.LOGWARNING)
        msg = "No direct stream URL available.\nThis match is only available via embedded web player."
        xbmcgui.Dialog().ok(ADDON_NAME, msg)
        xbmcplugin.setResolvedUrl(ADDON_HANDLE, False, xbmcgui.ListItem())

def router(param_string):
    """Routing logic based on URL parameters."""
    params = dict(urllib.parse.parse_qsl(param_string))
    mode = params.get('mode')

    if mode is None:
        menu_main()
    elif mode == 'matches':
        menu_matches(params.get('sport_id'), params.get('sport_name'))
    elif mode == 'streams':
        menu_streams(params.get('match_id'), params.get('sport_name'))
    elif mode == 'play':
        play_video(params.get('url'), params.get('playable'), params.get('referer'))
    elif mode == 'live_now':
        menu_live_now()
    elif mode == 'auto_play':
        auto_play(params.get('match_id'), params.get('sport_name'))
    elif mode == 'refresh_cache':
        refresh_cache()
    elif mode == 'clear_full_cache':
        clear_full_cache()

if __name__ == '__main__':
    router(sys.argv[2][1:])