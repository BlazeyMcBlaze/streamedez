import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import sys
import urllib.parse
import requests
import base64
import re
import certifi
from datetime import datetime, timedelta

try:
    from resources.lib.api_client import APIClient
    from resources.lib.cache_helper import CacheHelper
except ImportError:
    from api_client import APIClient
    from cache_helper import CacheHelper

ADDON = xbmcaddon.Addon()
ADDON_NAME = ADDON.getAddonInfo('name')
ADDON_HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]
BRIDGE_API_URL = ADDON.getSetting('api_bridge_url')

api_client = APIClient(BRIDGE_API_URL)
cache_helper = CacheHelper()

def log(msg, level=xbmc.LOGINFO):
    """Wrapper for xbmc logging."""
    xbmc.log(f"StreamedEZ: {msg}", level)

def build_url(query):
    """Constructs the plugin URL with query parameters."""
    return BASE_URL + '?' + urllib.parse.urlencode(query)

def get_sports_list():
    """Fetches list of sports, trying cache first then API."""
    cached = cache_helper.get('sports_list')
    if cached: return cached
    
    response = api_client.get_sports()
    if response and 'sports' in response:
        data = response['sports']
        cache_helper.set('sports_list', data, ttl_hours=24)
        return data
    return []

def get_kodi_data():
    """Fetches the main data payload from the API."""
    cached = cache_helper.get('kodi_data')
    if cached: return cached
    
    data = api_client.get_kodi_data()
    if data:
        cache_helper.set('kodi_data', data, ttl_hours=0.08) 
        return data
    return None

def format_match_time(ts):
    """Formats timestamp into readable string, handling LIVE status and relative dates."""
    if not ts: return ""
    try:
        ts = float(ts)
        if ts > 100000000000: ts = ts / 1000
        dt = datetime.fromtimestamp(ts)
        now = datetime.now()
        
        diff = (now - dt).total_seconds()
        
        # Modified: Shows LIVE status AND the start time
        if 0 <= diff <= (4 * 3600):
            return f"[COLOR red]LIVE[/COLOR] [{dt.strftime('%H:%M')}] "
        
        if dt.date() == now.date():
            return f"[{dt.strftime('%H:%M')}] "
        if dt.date() == (now + timedelta(days=1)).date():
            return f"Tomorrow [{dt.strftime('%H:%M')}] "
        return f"{dt.strftime('%a')} [{dt.strftime('%H:%M')}] "
    except: return ""

def menu_main():
    """Generates the main menu listing available sports."""
    sports = get_sports_list()
    if not sports:
        xbmcgui.Dialog().notification(ADDON_NAME, 'Failed to load sports', xbmcgui.NOTIFICATION_ERROR)
        return

    for sport in sports:
        url = build_url({'mode': 'matches', 'sport_id': sport['id'], 'sport_name': sport['name']})
        li = xbmcgui.ListItem(label=sport['name'])
        li.setInfo('video', {'title': sport['name'], 'plot': f"Browse {sport['name']} matches"})
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def menu_matches(sport_id, sport_name):
    """Generates the list of matches for a selected sport."""
    data = get_kodi_data()
    
    if not data or 'sports' not in data:
        xbmcgui.Dialog().notification(ADDON_NAME, 'No match data available', xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(ADDON_HANDLE)
        return

    target_sport = None
    for s in data['sports']:
        if s['name'].lower() == sport_id.lower() or s['name'].lower() == sport_name.lower():
            target_sport = s
            break
    
    if not target_sport or not target_sport.get('matches'):
        li = xbmcgui.ListItem(label="No matches found")
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(ADDON_HANDLE)
        return

    now_ts = datetime.now().timestamp()
    cutoff_ts = now_ts - (4 * 3600)
    
    valid_matches = []
    matches_247 = []
    
    for match in target_sport['matches']:
        start = match.get('start_time', 0)
        if start == 0:
            matches_247.append(match)
            continue
        try:
            ts_val = float(start)
            if ts_val > 100000000000: ts_val = ts_val / 1000
            if ts_val >= cutoff_ts:
                valid_matches.append(match)
        except: pass

    valid_matches.sort(key=lambda x: float(x.get('start_time', 0) or 0))
    all_display_matches = matches_247 + valid_matches

    if not all_display_matches:
        li = xbmcgui.ListItem(label="No upcoming matches")
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(ADDON_HANDLE)
        return

    for match in all_display_matches:
        title = match.get('title', 'Unknown Match')
        match_id = match.get('id')
        poster = match.get('poster')
        start_time = match.get('start_time')
        
        if start_time == 0:
            time_str = "[COLOR red]LIVE 24/7[/COLOR] "
        else:
            time_str = format_match_time(start_time)
        
        display_title = f"{time_str}{title}"
        
        url = build_url({
            'mode': 'streams', 
            'match_id': match_id,
            'sport_name': target_sport['name']
        })
        
        li = xbmcgui.ListItem(label=display_title)
        if poster and poster.startswith('http'):
            li.setArt({'thumb': poster, 'icon': poster, 'fanart': poster})
        
        li.setInfo('video', {'title': title, 'plot': title})
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def menu_streams(match_id, sport_name):
    """Generates the list of available streams for a specific match."""
    data = get_kodi_data()
    
    target_match = None
    search_order = []
    if sport_name:
        others = []
        for s in data.get('sports', []):
            if s['name'] == sport_name: search_order.append(s)
            else: others.append(s)
        search_order.extend(others)
    else:
        search_order = data.get('sports', [])

    for s in search_order:
        for m in s.get('matches', []):
            if str(m.get('id')) == str(match_id):
                target_match = m
                break
        if target_match: break
    
    if not target_match:
        xbmcgui.Dialog().notification(ADDON_NAME, 'Match data not found', xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(ADDON_HANDLE)
        return

    streams = target_match.get('streams', [])
    if not streams:
        li = xbmcgui.ListItem(label="No streams available")
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(ADDON_HANDLE)
        return

    # Modified: Enumerates streams as "Stream 1", "Stream 2" etc.
    for i, stream in enumerate(streams, 1):
        quality = stream.get('quality', 'SD')
        language = stream.get('language', 'En')
        
        media_url = stream.get('media_url') or stream.get('direct_url')
        embed_url = stream.get('url')
        
        if media_url:
            label = f"[{quality}] Stream {i} ({language}) [COLOR green]✓ Ready[/COLOR]"
            is_playable = 'true'
            play_url = media_url
        else:
            label = f"[{quality}] Stream {i} ({language}) [COLOR yellow]⚠ Web Only[/COLOR]"
            is_playable = 'false'
            play_url = embed_url

        url_params = {
            'mode': 'play',
            'url': play_url,
            'playable': is_playable,
            'referer': embed_url
        }
        url = build_url(url_params)
        
        li = xbmcgui.ListItem(label=label)
        li.setInfo('video', {'title': label})
        li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def play_video(url, playable, referer):
    """Handles playback with manifest correction for disguised streams."""
    if playable == 'true':
        try:
            log(f"Attempting playback for: {url}")
            
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                'Referer': referer if referer else url
            }
            
            # Use certifi for SSL verification if needed, or verify=False for speed/compatibility
            response = requests.get(url, headers=headers, timeout=15, verify=False)
            response.raise_for_status()
            
            playlist_content = response.text
            
            if '.png' in playlist_content:
                log("Detected disguised segments (.png), patching to .ts")
                modified_playlist = playlist_content.replace('.png', '.ts')
                
                encoded_playlist = base64.b64encode(modified_playlist.encode('utf-8')).decode('utf-8')
                play_url = f"data:application/vnd.apple.mpegurl;base64,{encoded_playlist}"
                log("Created in-memory modified playlist")
            else:
                play_url = url
                log("No disguised segments found, playing direct")

            li = xbmcgui.ListItem(path=play_url)
            li.setProperty('inputstream', 'inputstream.adaptive')
            li.setProperty('inputstream.adaptive.manifest_type', 'hls')
            
            ua = headers['User-Agent']
            ref = headers['Referer']
            stream_headers = f'User-Agent={ua}&Referer={ref}'
            
            li.setProperty('inputstream.adaptive.manifest_headers', stream_headers)
            li.setProperty('inputstream.adaptive.stream_headers', stream_headers)
            
            xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, li)
            
        except Exception as e:
            log(f"Playback failed: {e}", xbmc.LOGERROR)
            xbmcgui.Dialog().notification(ADDON_NAME, 'Playback Failed', xbmcgui.NOTIFICATION_ERROR)
            xbmcplugin.setResolvedUrl(ADDON_HANDLE, False, xbmcgui.ListItem())
    else:
        log(f"User clicked embed URL: {url}", xbmc.LOGWARNING)
        msg = f"Cannot play embed directly.\nURL: {url}"
        xbmcgui.Dialog().ok("StreamedEZ Error", msg)
        xbmcplugin.setResolvedUrl(ADDON_HANDLE, False, xbmcgui.ListItem())

def router(param_string):
    """Routing logic based on URL parameters."""
    params = dict(urllib.parse.parse_qsl(param_string))
    mode = params.get('mode')

    if mode is None:
        menu_main()
    elif mode == 'matches':
        menu_matches(params.get('sport_id'), params.get('sport_name'))
    elif mode == 'streams':
        menu_streams(params.get('match_id'), params.get('sport_name'))
    elif mode == 'play':
        play_video(params.get('url'), params.get('playable'), params.get('referer'))

if __name__ == '__main__':
    router(sys.argv[2][1:])