import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs
import os
import time
import threading
from datetime import datetime

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')

TARGET_MONTH = 12
TARGET_DAY = 25

def get_time_remaining():
    now = datetime.now()
    year = now.year
    target = datetime(year, TARGET_MONTH, TARGET_DAY, 0, 0, 0)
    
    if target < now:
        target = datetime(year + 1, TARGET_MONTH, TARGET_DAY, 0, 0, 0)
        
    delta = target - now
    is_christmas = (now.month == TARGET_MONTH and now.day == TARGET_DAY)
    return delta, is_christmas

def format_simple_days(delta):
    days = delta.days
    if days > 1:
        return f"{days} Days Left"
    elif days == 1:
        return "1 Day Left"
    elif days == 0:
        return "Christmas Eve!"
    else:
        return "Merry Christmas"

def ensure_bg_texture(addon_path):
    media_dir = os.path.join(addon_path, 'resources', 'media')
    if not os.path.exists(media_dir):
        try:
            os.makedirs(media_dir)
        except:
            pass
        
    bg_path = os.path.join(media_dir, 'bg.png')
    
    if not os.path.exists(bg_path):
        png_data = b'\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR\x00\x00\x00\x01\x00\x00\x00\x01\x08\x06\x00\x00\x00\x1f\x15\xc4\x89\x00\x00\x00\x0bIDAT\x08\xd7c\xf8\xff\xff?\x00\x05\xfe\x02\xfe\xdc\xccY\xe7\x00\x00\x00\x00IEND\xaeB`\x82'
        try:
            with open(bg_path, 'wb') as f:
                f.write(png_data)
        except:
            pass
    
    return bg_path

class CountdownDialog(xbmcgui.WindowDialog):
    def __init__(self):
        super(CountdownDialog, self).__init__()
        self.stop_event = threading.Event()
        self.update_thread = None
        self.start_time = 0
        self.bg_opacity = "99" 
        
        # --- DYNAMIC RESOLUTION ---
        try:
            self.screen_width = self.getWidth()
            self.screen_height = self.getHeight()
        except:
            self.screen_width = 1920
            self.screen_height = 1080
            
        if self.screen_width <= 0: self.screen_width = 1920
        if self.screen_height <= 0: self.screen_height = 1080

        addon_path = xbmcvfs.translatePath(ADDON.getAddonInfo('path'))
        bg_path = ensure_bg_texture(addon_path)
        snow_path = os.path.join(addon_path, 'resources', 'media', 'snow.png')
        santa_path = os.path.join(addon_path, 'resources', 'media', 'santa.png')
        
        # --- UI BUILD ---
        # 1. SNOW (Background)
        self.snow_img1 = None
        self.snow_img2 = None
        
        if os.path.exists(snow_path):
            self.snow_img1 = xbmcgui.ControlImage(0, 0, self.screen_width, self.screen_height, snow_path, aspectRatio=0)
            self.snow_img1.setColorDiffuse('0xFFFFFFFF') 
            self.snow_img2 = xbmcgui.ControlImage(0, -self.screen_height, self.screen_width, self.screen_height, snow_path, aspectRatio=0)
            self.snow_img2.setColorDiffuse('0xFFFFFFFF')
            self.addControl(self.snow_img1)
            self.addControl(self.snow_img2)

        # 2. CONTAINER BOX
        base_y = 50
        try:
            base_y = int(ADDON.getSetting('position_y'))
        except:
            pass
            
        box_width = 600
        box_height = 150
        padding_right = 50
        
        # DYNAMIC POSITION: Screen Width - Box Width - Padding
        box_x = self.screen_width - box_width - padding_right
        
        self.bg_box = xbmcgui.ControlImage(box_x, base_y, box_width, box_height, bg_path)
        self.bg_box.setColorDiffuse(f"0x{self.bg_opacity}000000") 
        self.addControl(self.bg_box)
        
        img_size = 100
        padding = 25

        # 3. TEXT LABEL (Left side of box)
        text_x = box_x + padding
        text_width = box_width - img_size - (padding * 3)
        
        # We removed title, so we center this vertically.
        # Box Height (150) - Label Height (80) / 2 = 35 offset
        self.label_time = xbmcgui.ControlLabel(text_x, base_y + 35, text_width, 80, "Loading...", 
                                             font='font60', alignment=0x0)
        self.addControl(self.label_time)

        # 4. FESTIVE IMAGE (Right side of box)
        self.img_static = None
        if os.path.exists(santa_path):
            img_x = box_x + box_width - img_size - padding
            self.img_static = xbmcgui.ControlImage(img_x, base_y + padding, img_size, img_size, santa_path, aspectRatio=1)
            self.addControl(self.img_static)
        else:
            xbmc.log(f"[{ADDON_ID}] DEBUG: santa.png not found at {santa_path}", xbmc.LOGINFO)
        
        self.apply_style()

    def apply_style(self):
        try:
            color = ADDON.getSetting('text_color')
            if not color: color = '0xFFE50914'
            self.label_time.setColor(color) 
        except Exception:
            pass

    def start_service(self):
        self.start_time = time.time()
        self.stop_event.clear()
        self.update_thread = threading.Thread(target=self._update_loop)
        self.update_thread.start()
        self.show()

    def _update_loop(self):
        try:
            duration = int(ADDON.getSetting('auto_close_time'))
        except:
            duration = 5 
            
        show_snow = (ADDON.getSetting('enable_snow') == 'true')
        
        if self.snow_img1:
            self.snow_img1.setVisible(show_snow)
            self.snow_img2.setVisible(show_snow)
            
        snow_y = 0.0
        last_frame_time = time.time()
        
        while not self.stop_event.is_set():
            now = time.time()
            dt = now - last_frame_time
            last_frame_time = now
            
            if duration > 0 and (now - self.start_time) > duration:
                break

            delta, is_christmas = get_time_remaining()
            if is_christmas:
                msg_time = ADDON.getSetting('holiday_message')
            else:
                msg_time = format_simple_days(delta)

            self.label_time.setLabel(msg_time)
            
            if show_snow and self.snow_img1:
                snow_y += 100 * dt
                if snow_y >= self.screen_height:
                    snow_y = 0
                self.snow_img1.setPosition(0, int(snow_y))
                self.snow_img2.setPosition(0, int(snow_y - self.screen_height))

            if self.stop_event.wait(0.03):
                break
        
        self.close()

    def close_cleanly(self):
        self.stop_event.set()
        if self.update_thread and threading.current_thread() != self.update_thread:
            self.update_thread.join()
        self.close()

    def onAction(self, action):
        if action.getId() in (9, 10, 92):
            self.close_cleanly()

class ServiceMonitor(xbmc.Monitor):
    def __init__(self):
        super(ServiceMonitor, self).__init__()
        self.dialog = None

    def onSettingsChanged(self):
        enabled = ADDON.getSetting('enable_overlay') == 'true'
        if not enabled and self.dialog:
            self.dialog.close_cleanly()
            self.dialog = None
        elif enabled and not self.dialog:
            self.show_dialog()
        elif self.dialog:
            self.dialog.apply_style()

    def show_dialog(self):
        if not self.dialog:
            self.dialog = CountdownDialog()
            self.dialog.start_service()
        
    def close_dialog(self):
        if self.dialog:
            self.dialog.close_cleanly()
            self.dialog = None

def run():
    monitor = ServiceMonitor()
    if not monitor.waitForAbort(5):
        if ADDON.getSetting('enable_overlay') == 'true':
            monitor.show_dialog()

    while not monitor.abortRequested():
        if monitor.waitForAbort(1):
            break
    monitor.close_dialog()

if __name__ == '__main__':
    run()